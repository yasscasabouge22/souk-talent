import { projectId, publicAnonKey } from '../../utils/supabase/info';
import { createClient } from '@supabase/supabase-js';

const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-72d55e0a`;

// Create Supabase client for authentication
export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

// Helper to get auth token
const getAuthToken = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  return session?.access_token || null;
};

// Helper for API requests
const apiRequest = async (endpoint: string, options: RequestInit = {}) => {
  const token = await getAuthToken();
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  } else {
    headers['Authorization'] = `Bearer ${publicAnonKey}`;
  }

  const response = await fetch(`${API_URL}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(error.error || `HTTP error! status: ${response.status}`);
  }

  return response.json();
};

// ==================== AUTH API ====================

export const authAPI = {
  // Sign up as artist
  signupArtist: async (data: {
    email: string;
    password: string;
    name: string;
    phone: string;
    artistType: string;
  }) => {
    return apiRequest('/auth/signup/artist', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Sign up as organizer
  signupOrganizer: async (data: {
    email: string;
    password: string;
    name: string;
    phone: string;
  }) => {
    return apiRequest('/auth/signup/organizer', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Sign in (use Supabase directly)
  signin: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;
    return data;
  },

  // Sign out
  signout: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },

  // Get current session
  getSession: async () => {
    const { data: { session } } = await supabase.auth.getSession();
    return session;
  },

  // Get current user
  getUser: async () => {
    const { data: { user } } = await supabase.auth.getUser();
    return user;
  },

  // Create agent account
  createAgent: async (data: {
    email: string;
    password: string;
    name: string;
  }) => {
    return apiRequest('/auth/create-agent', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },
};

// ==================== PROFILE API ====================

export const profileAPI = {
  // Get artist profile
  getArtistProfile: async (id: string) => {
    return apiRequest(`/profile/artist/${id}`);
  },

  // Update artist profile
  updateArtistProfile: async (data: any) => {
    return apiRequest('/profile/artist', {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  // Get organizer profile
  getOrganizerProfile: async (id: string) => {
    return apiRequest(`/profile/organizer/${id}`);
  },

  // Update organizer profile
  updateOrganizerProfile: async (data: any) => {
    return apiRequest('/profile/organizer', {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  // Search artists
  searchArtists: async (filters?: {
    category?: string;
    genre?: string;
    location?: string;
    minPrice?: number;
    maxPrice?: number;
  }) => {
    const params = new URLSearchParams();
    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined) params.append(key, value.toString());
      });
    }
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiRequest(`/artists/search${query}`);
  },
};

// ==================== AVAILABILITY API ====================

export const availabilityAPI = {
  // Get artist availability
  getAvailability: async (artistId: string) => {
    return apiRequest(`/availability/${artistId}`);
  },

  // Update availability
  updateAvailability: async (date: string, status: string) => {
    return apiRequest('/availability', {
      method: 'PUT',
      body: JSON.stringify({ date, status }),
    });
  },
};

// ==================== BOOKING API ====================

export const bookingAPI = {
  // Create booking request
  createBooking: async (data: {
    artistId: string;
    date: string;
    eventType: string;
    message: string;
    location: string;
  }) => {
    return apiRequest('/bookings', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Get artist bookings
  getArtistBookings: async () => {
    return apiRequest('/bookings/artist');
  },

  // Get organizer bookings
  getOrganizerBookings: async () => {
    return apiRequest('/bookings/organizer');
  },

  // Update booking status
  updateBookingStatus: async (bookingId: string, status: string) => {
    return apiRequest(`/bookings/${bookingId}`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  },
};

// ==================== ANNOUNCEMENTS API ====================

export const announcementAPI = {
  // Create announcement
  createAnnouncement: async (data: {
    title: string;
    description: string;
    eventType: string;
    date: string;
    location: string;
    budget: string;
  }) => {
    return apiRequest('/announcements', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Get all announcements
  getAnnouncements: async () => {
    return apiRequest('/announcements');
  },

  // Apply to announcement
  applyToAnnouncement: async (announcementId: string, data: {
    message: string;
    proposedPrice: string;
  }) => {
    return apiRequest(`/announcements/${announcementId}/apply`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },
};

// ==================== EVENTS API ====================

export const eventsAPI = {
  // Create public event
  createEvent: async (data: any) => {
    return apiRequest('/events', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Get all public events
  getEvents: async () => {
    return apiRequest('/events');
  },
};

// ==================== MESSAGES API ====================

export const messagesAPI = {
  // Send message
  sendMessage: async (data: {
    recipientId: string;
    content: string;
    bookingId?: string;
  }) => {
    return apiRequest('/messages', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Get user messages
  getMessages: async () => {
    return apiRequest('/messages');
  },
};